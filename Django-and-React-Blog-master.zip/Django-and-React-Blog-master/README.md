# Milestone 🪨 Tracker 🕐
---
1. Started Project on the 21 March, 2024 9:58pm
2. Completed all the frontend pages development on the 22 March, 2024 12:54am
3. Completed all the backend api views and testing on the 22 March, 2024 7:07 pm
4. Integrated authentication apis to frontend on the 23 March, 2024 9:55 am
5. Implemented author posts, comments and notifications on the 24 March, 2024 11:06 pm
6. (Completed V1 in 5 Days) Integrated post create api to frontend on the 25 march, 2024 5:46 pm
